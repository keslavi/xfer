var suite = require('./harness');

exports.level1 = {
  core: suite('level1/core/'),
  html: suite('level1/html/')
};
/*
exports.level2 = {
  core: suite('level2/core/'),
  html: suite('level2/html/')
};
*/