var convert = require('./convert'),
    func = convert('wrapperAt', require('../wrapperAt'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
