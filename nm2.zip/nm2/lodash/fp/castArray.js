var convert = require('./convert'),
    func = convert('castArray', require('../castArray'));

func.placeholder = require('./placeholder');
module.exports = func;
