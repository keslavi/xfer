var convert = require('./convert'),
    func = convert('toIterator', require('../toIterator'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
