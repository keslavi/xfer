module.exports = require('./dropRight');
